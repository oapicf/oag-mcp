
# Visit


## Properties

Name | Type
------------ | -------------
`id` | number
`date` | Date
`reason` | string
`costCents` | number

## Example

```typescript
import type { Visit } from 'petclinic-sdk'

// TODO: Update the object below with actual values
const example = {
  "id": null,
  "date": null,
  "reason": null,
  "costCents": null,
} satisfies Visit

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as Visit
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)


